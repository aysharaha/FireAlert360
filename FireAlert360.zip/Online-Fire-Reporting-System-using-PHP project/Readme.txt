How to run the Online Fire Reporting System Project using PHP and MySQL
1. Download the project zip file

2. Extract the file and copy ofrs folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4.Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name  ofrsdb

6. Import ofrsdb.sql file(given inside the zip package in SQL file folder)

7. Run the script http://localhost/ofrs

Admin Credential
Username: admin
Password: Test@123